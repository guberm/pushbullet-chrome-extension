'use strict'

var setUpNotificationsContent = function() {
    notificationsChangedListener()
    pb.addEventListener('notifications_changed', notificationsChangedListener)
}

var tearDownNotificationsContent = function() {
    pb.removeEventListener('notifications_changed', notificationsChangedListener)
}

var notificationsChangedListener = function() {
    if (!window) {
        return
    }
    if (!pb.notifier || !pb.notifier.active) {
        return
    }

    var count = Object.keys(pb.notifier.active).length
    var tab = document.getElementById('notifications-tab-label')
    if (count > 0) {
        tab.textContent = chrome.i18n.getMessage('notifications') + ' (' + count + ')'
    } else {
        tab.textContent = chrome.i18n.getMessage('notifications')
    }
    
    updateNotifications()
}

var updateNotifications = function() {
    var notificationsHolder = document.getElementById('notifications-holder')
    var emptyHolder = document.getElementById('notifications-empty')

    while (notificationsHolder.firstChild) {
        notificationsHolder.removeChild(notificationsHolder.firstChild)
    }

    var keys = Object.keys(pb.notifier.active)
    if (keys.length > 0) {
        notificationsHolder.style.display = 'block'
        emptyHolder.style.display = 'none'

        keys.forEach(function(key) {
            var options = pb.notifier.active[key]

            notificationsHolder.insertBefore(fakeNotifications.renderNotification(options, function() {
                clearNotification(options)
            }), notificationsHolder.firstChild)
        })
    } else {
        notificationsHolder.style.display = 'none'
        emptyHolder.style.display = 'block'
    }
}

var clearNotification = function(options) {
    // Delegate to background via RPC so pb.notifier.active is authoritatively
    // updated in the background and the state broadcast properly removes the
    // notification from the panel on the next pb_state_update.
    pb.notifier.dismiss(options.key)
}
